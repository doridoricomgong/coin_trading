#-*-coding:utf-8 -*-
'''
이 키값을 그대로 쓰셔도 되지만 아나콘다 쥬피터 노트북 상에서 아래 로직 실행해서 새로 키를 받으세요.
물론 비쥬얼 스튜디오 코드에서도 아래처럼 코딩해서 키 값을 얻으셔도 되요. 편하신 걸로 ㅎ

from cryptography.fernet import Fernet

Key = Fernet.generate_key()

print(Key)

'''
ende_key = b'NcUgge50agCYGXpJmpcxsE5_0do84kKNdI6DsG-iwm8='